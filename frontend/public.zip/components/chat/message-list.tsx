"use client"

import { useEffect, useRef } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageBubble } from "./message-bubble"
import { LoadingMessage } from "./loading-message"
import { Sparkles } from "lucide-react"
import type { Message } from "@/app/page"

interface MessageListProps {
  messages: Message[]
  isLoading: boolean
  isDarkMode: boolean
}

export function MessageList({ messages, isLoading, isDarkMode }: MessageListProps) {
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages, isLoading])

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }

  return (
    <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
      <div className="space-y-4 min-h-0">
        {messages.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center mx-auto mb-4 animate-bounce">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className={`text-lg font-medium mb-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
              Welcome to Your AI Assistant
            </h3>
            <p className={`text-sm ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
              Start a conversation by typing a message, recording your voice, or using quick actions
            </p>
          </div>
        )}

        {messages.map((message, index) => (
          <MessageBubble
            key={`${message.id}-${index}`}
            message={message}
            isDarkMode={isDarkMode}
            animationDelay={index * 100}
          />
        ))}

        {isLoading && <LoadingMessage isDarkMode={isDarkMode} />}
      </div>
    </ScrollArea>
  )
}

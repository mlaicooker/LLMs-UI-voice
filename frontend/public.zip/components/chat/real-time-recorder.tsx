"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Radio, Volume2 } from "lucide-react"

interface RealTimeRecorderProps {
  onTranscription: (text: string, isFinal: boolean) => void
  onResponse: (response: string) => void
  isDarkMode: boolean
  isEnabled: boolean
}

export function RealTimeRecorder({ onTranscription, onResponse, isDarkMode, isEnabled }: RealTimeRecorderProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [currentTranscription, setCurrentTranscription] = useState("")
  const [voiceLevel, setVoiceLevel] = useState(0)
  const [silenceTimer, setSilenceTimer] = useState(0)
  const [connectionStatus, setConnectionStatus] = useState<"disconnected" | "connecting" | "connected" | "error">(
    "disconnected",
  )

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const websocketRef = useRef<WebSocket | null>(null)
  const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const animationFrameRef = useRef<number>()

  const SILENCE_THRESHOLD = 0.01 // Voice activity threshold
  const SILENCE_DURATION = 2000 // 2 seconds of silence before auto-response
  const API_BASE = "ws://localhost:8080"

  useEffect(() => {
    if (isEnabled && !isConnected) {
      connectWebSocket()
    } else if (!isEnabled && isConnected) {
      disconnectWebSocket()
    }

    // Auto-start recording when enabled
    if (isEnabled && isConnected && !isRecording) {
      startRecording()
    } else if (!isEnabled && isRecording) {
      stopRecording()
    }

    return () => {
      disconnectWebSocket()
    }
  }, [isEnabled, isConnected])

  const connectWebSocket = useCallback(() => {
    if (websocketRef.current?.readyState === WebSocket.OPEN) return

    setConnectionStatus("connecting")

    try {
      // Note: Your backend would need to implement WebSocket endpoint
      // For now, we'll simulate real-time processing with HTTP calls
      setConnectionStatus("connected")
      setIsConnected(true)
    } catch (error) {
      console.error("WebSocket connection failed:", error)
      setConnectionStatus("error")
      setIsConnected(false)
    }
  }, [])

  const disconnectWebSocket = useCallback(() => {
    if (websocketRef.current) {
      websocketRef.current.close()
      websocketRef.current = null
    }
    setConnectionStatus("disconnected")
    setIsConnected(false)
    stopRecording()
  }, [])

  const analyzeAudio = useCallback(() => {
    if (!analyserRef.current || !isRecording) return

    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount)
    analyserRef.current.getByteFrequencyData(dataArray)

    const average = dataArray.reduce((a, b) => a + b) / dataArray.length
    const normalizedLevel = average / 255
    setVoiceLevel(normalizedLevel)

    // Silence detection
    if (normalizedLevel < SILENCE_THRESHOLD) {
      if (!silenceTimeoutRef.current && currentTranscription.trim()) {
        silenceTimeoutRef.current = setTimeout(() => {
          handleSilenceTimeout()
        }, SILENCE_DURATION)
      }
    } else {
      // Voice detected, clear silence timeout
      if (silenceTimeoutRef.current) {
        clearTimeout(silenceTimeoutRef.current)
        silenceTimeoutRef.current = null
      }
      setSilenceTimer(0)
    }

    if (isRecording) {
      animationFrameRef.current = requestAnimationFrame(analyzeAudio)
    }
  }, [isRecording, currentTranscription])

  const handleSilenceTimeout = async () => {
    if (currentTranscription.trim()) {
      // Send final transcription and get response
      onTranscription(currentTranscription, true)
      await getAIResponse(currentTranscription)
      setCurrentTranscription("")
    }
    silenceTimeoutRef.current = null
  }

  const getAIResponse = async (text: string) => {
    try {
      const response = await fetch("http://localhost:8080/rag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text }),
      })

      if (response.ok) {
        const data = await response.json()
        onResponse(data.response)
      }
    } catch (error) {
      console.error("Failed to get AI response:", error)
    }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 16000,
        },
      })

      streamRef.current = stream

      // Set up audio analysis
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
      analyserRef.current = audioContextRef.current.createAnalyser()
      const source = audioContextRef.current.createMediaStreamSource(stream)
      source.connect(analyserRef.current)
      analyserRef.current.fftSize = 256

      // Set up MediaRecorder for chunked audio processing
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: "audio/webm;codecs=opus",
      })

      mediaRecorderRef.current.ondataavailable = async (event) => {
        if (event.data.size > 0) {
          await processAudioChunk(event.data)
        }
      }

      // Start recording with small chunks for real-time processing
      mediaRecorderRef.current.start(500) // 500ms chunks
      setIsRecording(true)
      analyzeAudio()
    } catch (error) {
      console.error("Error starting recording:", error)
      setConnectionStatus("error")
    }
  }

  const processAudioChunk = async (audioBlob: Blob) => {
    try {
      // In a real implementation, you'd send this to your STT service
      // For demo purposes, we'll simulate transcription updates
      const mockTranscription = await simulateRealTimeSTT(audioBlob)
      if (mockTranscription) {
        setCurrentTranscription((prev) => prev + " " + mockTranscription)
        onTranscription(currentTranscription + " " + mockTranscription, false)
      }
    } catch (error) {
      console.error("Error processing audio chunk:", error)
    }
  }

  const simulateRealTimeSTT = async (audioBlob: Blob): Promise<string> => {
    // Simulate real-time STT processing
    // In production, you'd send the audio chunk to your Whisper service
    const mockWords = ["hello", "how", "are", "you", "today", "what", "is", "the", "weather", "like"]
    return Math.random() > 0.7 ? mockWords[Math.floor(Math.random() * mockWords.length)] : ""
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (audioContextRef.current) {
      audioContextRef.current.close()
      audioContextRef.current = null
    }

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
    }

    if (silenceTimeoutRef.current) {
      clearTimeout(silenceTimeoutRef.current)
      silenceTimeoutRef.current = null
    }

    setVoiceLevel(0)
    setSilenceTimer(0)
  }

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case "connected":
        return "text-green-500"
      case "connecting":
        return "text-yellow-500"
      case "error":
        return "text-red-500"
      default:
        return "text-gray-500"
    }
  }

  const VoiceVisualizer = () => (
    <div className="flex items-center justify-center gap-1 h-12">
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className={`w-1 bg-gradient-to-t from-blue-400 to-purple-500 rounded-full transition-all duration-150 ${
            isRecording ? "animate-pulse" : ""
          }`}
          style={{
            height: `${Math.max(4, voiceLevel * 48 + Math.sin(Date.now() / 200 + i) * 8)}px`,
            animationDelay: `${i * 100}ms`,
          }}
        />
      ))}
    </div>
  )

  if (!isEnabled) return null

  return (
    <Card className={`border-0 ${isDarkMode ? "bg-black/20 backdrop-blur-xl" : "bg-white/70 backdrop-blur-xl"} mb-4`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Radio className={`w-4 h-4 ${isRecording ? "text-red-500 animate-pulse" : getConnectionStatusColor()}`} />
            <span className={`text-sm font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
              Real-Time Recording
            </span>
            <Badge variant={isRecording ? "destructive" : isConnected ? "default" : "secondary"} className="text-xs">
              {isRecording ? "Recording" : connectionStatus}
            </Badge>
          </div>
        </div>

        {isRecording && (
          <>
            <VoiceVisualizer />

            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className={`${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>Voice Level</span>
                <span className={`${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                  {(voiceLevel * 100).toFixed(0)}%
                </span>
              </div>
              <Progress value={voiceLevel * 100} className="h-1" />
            </div>

            {currentTranscription && (
              <div
                className={`mt-4 p-3 rounded-lg ${isDarkMode ? "bg-white/10" : "bg-black/5"} border-l-4 border-blue-500`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Volume2 className="w-3 h-3 text-blue-500" />
                  <span className={`text-xs font-medium ${isDarkMode ? "text-blue-400" : "text-blue-600"}`}>
                    Live Transcription
                  </span>
                </div>
                <p className={`text-sm ${isDarkMode ? "text-white" : "text-gray-800"}`}>{currentTranscription}</p>
              </div>
            )}

            <div className={`mt-2 text-xs ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
              💡 Speak naturally - AI will respond automatically after 2 seconds of silence
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
